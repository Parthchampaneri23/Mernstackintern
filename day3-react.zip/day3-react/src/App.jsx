import "./App.css";
import StudentContainer from "./components/StudentContainer";

function App() {

  const scrollToDashboard = () => {

    const section = document.getElementById("developers");

    section.scrollIntoView({
      behavior: "smooth",
    });
  };

  return (
    <div className="app">

      {/* NAVBAR */}

      <div className="navbar">

        <div className="brand">

          <div className="brand-logo">
            ⚡
          </div>

          <h2>NovaStack</h2>

        </div>

        <button
          className="nav-button"
          onClick={scrollToDashboard}
        >
          Open Dashboard
        </button>

      </div>

      {/* HERO SECTION */}

      <div className="hero-section">

        <div className="hero-badge">
          ✨ Next Generation Developer Platform
        </div>

        <h1 className="heading">
          Where Developers Grow 🚀
        </h1>

        <p className="sub-heading">
          Showcasing modern frontend development,
          interactive UI design, and scalable
          React architecture.
        </p>

        <div className="tag-line">
          🚀 Build • Learn • Innovate
        </div>

      </div>

      {/* DASHBOARD */}

      <div id="developers">

        <StudentContainer />

      </div>

      {/* FOOTER */}

      <div className="footer">
        ❤️ Built with React & Modern UI Design
      </div>

    </div>
  );
}

export default App;