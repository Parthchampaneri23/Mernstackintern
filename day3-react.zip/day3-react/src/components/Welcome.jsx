function Welcome() {
  return (
    <div>
      <h1>Welcome to Day 3 🚀</h1>
    </div>
  );
}

export default Welcome;