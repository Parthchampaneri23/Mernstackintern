import { useState } from "react";

import StudentCard from "./StudentCard";

import {
  Code2,
  Cpu,
  Rocket,
  Sparkles,
} from "lucide-react";

function StudentContainer() {

  const [selectedStudent, setSelectedStudent] = useState(null);

  const [search, setSearch] = useState("");

  const students = [

    {
      icon: Code2,
      color: "#3b82f6",

      name: "Parth",

      role: "Frontend Developer",

      course: "MERN Stack",

      skills: ["React", "JavaScript", "CSS"],

      description:
        "Passionate frontend developer creating modern UI experiences.",

      project: "Student Management System",
    },

    {
      icon: Cpu,
      color: "#8b5cf6",

      name: "Rahul",

      role: "React Developer",

      course: "React JS",

      skills: ["React", "Tailwind", "Firebase"],

      description:
        "Focused on reusable components and responsive design.",

      project: "Weather App",
    },

    {
      icon: Rocket,
      color: "#ec4899",

      name: "Amit",

      role: "Backend Developer",

      course: "Node JS",

      skills: ["Node", "MongoDB", "Express"],

      description:
        "Backend enthusiast building scalable APIs.",

      project: "Task Manager API",
    },

    {
      icon: Sparkles,
      color: "#14b8a6",

      name: "Riya",

      role: "Full Stack Developer",

      course: "Full Stack",

      skills: ["React", "Node", "MongoDB"],

      description:
        "Creative developer building modern full stack apps.",

      project: "E-Commerce Website",
    },
  ];

  const filteredStudents = students.filter((student) =>
    student.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>

      {/* SEARCH BAR */}

      <div className="search-box">

        <input
          type="text"
          placeholder="🔍 Search Developers..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

      </div>

      {/* STUDENT CARDS */}

      <div className="card-container">

        {filteredStudents.map((student, index) => (

          <div
            key={index}
            onClick={() => setSelectedStudent(student)}
          >

            <StudentCard student={student} />

          </div>

        ))}

      </div>

      {/* MODAL POPUP */}

      {selectedStudent && (() => {

        const ModalIcon = selectedStudent.icon;
 
        return (

          <div
            className="modal-overlay"
            onClick={() => setSelectedStudent(null)}
          >

            <div
              className="modal-card"
              onClick={(e) => e.stopPropagation()}
            >

              <div
                className="avatar modal-avatar"
                style={{ background: selectedStudent.color }}
              >
                <ModalIcon size={50} />
              </div>

              <h1>{selectedStudent.name}</h1>

              <h3>{selectedStudent.role}</h3>

              <p>{selectedStudent.description}</p>

              <h2>🚀 Project</h2>

              <p>{selectedStudent.project}</p>

              <div className="skills">

                {selectedStudent.skills.map((skill, index) => (

                  <span key={index}>
                    {skill}
                  </span>

                ))}

              </div>

              <button
                className="close-btn"
                onClick={() => setSelectedStudent(null)}
              >
                Close
              </button>

            </div>

          </div>

        );

      })()}

    </div>
  );
}

export default StudentContainer;