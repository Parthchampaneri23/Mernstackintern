function StudentCard({ student }) {

  const Icon = student.icon;

  return (
    <div className="student-card">

      {/* AVATAR */}

      <div
        className="avatar"
        style={{ background: student.color }}
      >
        <Icon size={42} />
      </div>

      {/* ONLINE STATUS */}

      <div className="online-dot"></div>

      {/* NAME */}

      <h2>{student.name}</h2>

      {/* ROLE */}

      <h3>{student.role}</h3>

      {/* COURSE */}

      <p>{student.course}</p>

      {/* SKILLS */}

      <div className="skills">

        {student.skills.map((skill, index) => (

          <span key={index}>
            {skill}
          </span>

        ))}

      </div>

    </div>
  );
}

export default StudentCard;