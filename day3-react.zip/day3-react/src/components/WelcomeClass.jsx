import React, { Component } from "react";

class WelcomeClass extends Component {
  render() {
    return (
      <div>
        <h2>This is Class Component 🔥</h2>
      </div>
    );
  }
}

export default WelcomeClass;